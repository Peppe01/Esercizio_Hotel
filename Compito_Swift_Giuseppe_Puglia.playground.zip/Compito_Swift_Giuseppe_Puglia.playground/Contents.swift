import UIKit

var str = "Compito di Swift"
print()

/* Risposte delle domande
 
 1. Le Tuple sono un insieme di due o più valori in un singolo valore composto. Una tupla è di tipo (Int, String) e viene definita dalla lista dei suoi valori, separati da una virgola tra parentesi. E' possibile usare qualsiasi tipo come membro di una tupla, anche tipi opzionali.
     Esempio di una tupla:
     var esempioTupla: (Int, String) = (1000, "Sono una Tupla")
     print(esempioTupla.0)
     print(esempioTupla.1)
 
 2. Per rappresentare una tupla ci sono due modi:
    Modo N1: usando un indice che fa riferimento alla posizione dell'elemento all'interno della          tupla, es:
             var ciao: (Int, String) = (10, "Ciao")
             print(ciao.0)
             print(ciao.1)
 
     Modo N2: assegnando un nome alle componenti della tupla, es:
              var compito: (Int, String) = (votoCompito: 60, esitoCompito: "Promosso")
              print(compito.votoCompito)
              print(compito.esitoCompito)
 
 3. Per effettuare la modifica da "E" in "C", si fa questa procedura:
    var array: [String] = ["A", "B", "E", "D"];
    array[2] = "C"
    print(array)
 
 4. Per accedere in maniera diretta una value di una dictionary si usa questa procedimento:
     var cibo: [
     "P" : "Pizza",
     "A" : "Ananas"
 ]

 var a = cibo["A"]
 cibo["P"]
 
 5. Esempio Optional Binding con una variabile Optional

 var str: String?
 
 str = "Oggi è un bel tempo"

 if let myStr = str {
     print(myStr)
 } else{
     print("Oggi il tempo fa schifo")
 }

 6. Stessa cosa ma con Guard
 
       func addHello(hello: String?) {
         guard let newHello = hello
            else {
             return
         }
         print(newHello)
     }
addHello(hello: "Hello, Dude")
 
 
 7. Le Computed Property sono delle speciali proprietà che possono svolgere dei calcoli quando vi si accede o si prova a modificarne il loro valore. In pratica si comportano come delle piccole funzioni.
    Esempio:
        var name: String
        
        private var hello: String
        
        var cpHello: String {
            get {
                print ("Hello, Dude")
                return self.hello
            }
            set(newValue){
                self.hello = newValue
        }
  Una proprietà get ti permette di accedere solamente al suo valore o al valore di altre proprietà ma non ti
  permette di assegnargli un nuovo valore. Una property Set modifica il valore di un’altra proprietà della
  classe passando il valore a questa nuova proprietà set.
  */

/*
 ESERCIZIO SWIFT
 Un Albergo richiede la creazione di un’applicazione per la
 gestione e prenotazione delle sue camere.

 L’albergo gestisce delle Stanze.
 Ogni camera ha una property che la identifica
 univocamente.
 Esistono due tipologie di Stanza: Singola e Doppia.
 La Singola può ospitare al massimo una persona ed in
 più qualche singola (non tutte) può avere la possibilità di avere
 un cucinino.
 la Doppia può ospitare due persone, non può avere cucinino
 ma qualche doppia (non tutte) potrebbe avere la possibilità di
 aggiungere un terzo lettino (cosa che non può avere la stanza
 singola)
 Ogni camera può essere prenotata.
 Una funzione dell’albergo mostra tutte le camere libere sia
 singole che doppie ognuna con le sue caratteristiche
 (Cucinino / Terzo lettino)
 Una funzione dell’Albergo permette di prenotare una camera
 che sia identificata come “libera” in base alla scelta svolta
 dall’utente. (Singola, Singola con Cucinino, Doppia, Doppia
 con Lettino)

 Se un utente chiede di prenotare una stanza “Singola” o
 “Doppia” (e con le opportuni varianti) la nostra funzione deve
 essere in grado di effettuare una ricerca tra tutte le stanze in
 modo da poter ritornare una stanza che non sia occupata per
 poterla in seguito prenotare.
 Se non ci sono stanze libere, deve mandare in Output un
 messaggio all’utente :
 “Ci dispiace ma non ci sono al momento stanze con le
 caratteristiche da Lei richieste.”
 Se esiste la Stanza e questa è libera, un’altra funzione deve
 permettere all’utente di prenotarla, settando la stessa come
 occupata.
 Trovare il modo migliore per simulare la prenotazione di una
 stanza.
 Utilizzate L’ereditarietà typeCasting e DownCasting e
 Extension dove serve.
 */

class Albergo{
    var stanze : [Stanze] = []
    
    init(stanze: [Stanze]) {
        self.stanze = stanze
    }
    
    func stampaStanze(){
        for stanza in self.stanze{
            if stanza is Singola && stanza.prenotata == false{
                print("\nLa stanza singola Numero \(stanza.codice) a disposizione con il cucinino")
            } else if stanza is Doppia && stanza.prenotata == false{
                print("\nLa stanza doppia Numero \(stanza.codice) a dispozione con il terzo lettino")
            } else {
                print("\nLa stanza numero \(stanza.codice) è in lavorazione.")
            }
        }
    }
    
    func stanzaPrenotata(tipo: String){
        switch tipo {
        case "Stanza singola con il cucinino":
            for stanza in self.stanze{
                if stanza is Singola && stanza.prenotata == false{
                    if let singola = stanza as? Singola{
                        if singola.self.cucinino{
                            stanza.prenotata = true
                            print("\nStanza singola con il cucinino numero \(stanza.codice) è prenotata")
                            return
                        }
                    }
                }
            }
            break
        case "Stanza doppia con il terzo lettino":
            for stanza in self.stanze{
                if stanza is Doppia && stanza.prenotata == false{
                    if let doppia = stanza as? Doppia{
                        if doppia.self.terzoLettino{
                            stanza.prenotata = true
                            print("\nStanza doppia con il terzo lettino numero \(stanza.codice) è prenotata")
                            return
                        }
                    }
                }
            }
            break
        case "Stanza Doppia":
            for stanza in self.stanze{
                if stanza is Doppia && stanza.prenotata == false{
                    stanza.prenotata = true
                    print("\nStanza doppia numero \(stanza.codice) è prenotata")
                    return
                }
            }
            break
        case "Stanza singola":
            for stanza in self.stanze{
                if stanza is Singola && stanza.prenotata == false{
                    stanza.prenotata = true
                    print("\nStanza singola numero \(stanza.codice) è prenotata")
                    return
                }
            }
        default:
            print("\nTutte le stanza sono prenotate, impossibile prenotarla")
        }
    }
}

class Stanze{
    var numeroPersone: Int
    var prenotata: Bool
    var codice: String
    
    init(numeroPersone: Int, prenotata: Bool, codice: String) {
        self.numeroPersone = numeroPersone
        self.prenotata = prenotata
        self.codice = codice
    }
}

class Singola : Stanze{
    var cucinino: Bool
    
    init(codice: String, cucinino: Bool){
        self.cucinino = cucinino
        super.init(numeroPersone: 1, prenotata: false, codice: codice)
    }
}

class Doppia : Stanze{
    var terzoLettino: Bool
    
    init(codice: String, terzoLettino: Bool) {
        self.terzoLettino = terzoLettino
        super.init(numeroPersone: 3, prenotata: false, codice: codice)
    }
}

var stanzaN1 = Singola.init(codice: "666666", cucinino: true)
var stanzaN2 = Singola.init(codice: "000000", cucinino: true)
var stanzaN3 = Doppia.init(codice: "123456", terzoLettino: true)
var stanzaN4 = Doppia.init(codice: "0101010", terzoLettino: true)
var albergo = Albergo.init(stanze: [stanzaN1, stanzaN2, stanzaN3, stanzaN4])
albergo.stampaStanze()
albergo.stanzaPrenotata(tipo: "Stanza con il cucinino")
albergo.stanzaPrenotata(tipo: "Stanza con il terzo lettino")
albergo.stanzaPrenotata(tipo: "Stanza Singola")
albergo.stanzaPrenotata(tipo: "Stanza Doppia")


